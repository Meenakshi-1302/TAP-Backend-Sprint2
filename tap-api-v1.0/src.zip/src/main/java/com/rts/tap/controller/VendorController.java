package com.rts.tap.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.rts.tap.constants.APIConstants;
import com.rts.tap.constants.MessageConstants;
import com.rts.tap.dto.VendorDto;
import com.rts.tap.model.Vendor;
import com.rts.tap.service.VendorService;

import jakarta.mail.MessagingException;
import jakarta.mail.Multipart;

/** 
 * author: Jeevarajan Rajarajacholan, Vasanth Thopey Sivakumar
 * version: v1.0
 * updated at: 04-11-2024
**/

@RestController
@CrossOrigin(APIConstants.CROSS_ORIGIN_URL)
@RequestMapping(APIConstants.VENDOR_URL)
public class VendorController {

    private VendorService vendorService;
    private static final Logger logger = LoggerFactory.getLogger(VendorController.class);

    public VendorController(VendorService vendorService) {
        this.vendorService = vendorService;
    }

    /**
	 * this api will accept Vendor dto and perform add operation and return Vendor object
	 * @param(vendor's Organization Name) - String
	 * @param(vendor's email Id) - String  
	 * @return Vendor - object
	**/
    @PostMapping
	public ResponseEntity<Vendor> doAddNewVendor(@RequestBody VendorDto vendorDto) throws MessagingException{		
		return new ResponseEntity<>(vendorService.addNewVendor(vendorDto),HttpStatus.OK);
	}

    /**
	 * this api will accept vendor id and perform fetch operation and return VendorDto as object
	 * @param(vendor's id) - long  
	 * @return VendorDto - object
	**/
    
    
    @GetMapping(APIConstants.VENDOR_GET_BY_ID)
    public ResponseEntity<VendorDto> getVendorById(@PathVariable Long id) {
        return ResponseEntity.ok(vendorService.getVendorById(id));
    }

    /**
	 * this api will perform fetch operation and return all vendors available 
	 * in list of VendorDto as object  
	 * @return list of VendorDto - object
	**/
    @GetMapping(APIConstants.VENDOR_GET_ALL)
    public ResponseEntity<List<VendorDto>> getAllVendors() {
        return ResponseEntity.ok(vendorService.getAllVendors());
    }

    /**
	 * this api will accept Vendor dto and vendor Id and perform udpate operation and return Vendor object
	 * sample params
	 * @param(vendor's Organization Name) - String
	 * @param(vendor's email Id) - String, 
	 * @return Vendor - object
	**/
    @PutMapping(APIConstants.VENDOR_UPDATE)
    public ResponseEntity<Vendor> doUpdateVendor(@PathVariable Long id, @RequestBody VendorDto vendor) {
        try {
            Vendor updatedVendor = vendorService.updateVendor(id, vendor);
            if (updatedVendor == null) {
                return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(updatedVendor, HttpStatus.OK);
        } catch (Exception e) {
            // Log the exception for debugging
            logger.error("Error updating vendor", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
	 * this api will accept vendor id and perform delete operation and return deletion message
	 * @param(vendor's id) - long  
	 * @return String - message for deletion status
	**/
    @DeleteMapping(APIConstants.VENDOR_DELETE)
    public ResponseEntity<String> doDeleteVendor(@PathVariable Long id) {
    	try {
    		vendorService.deleteVendor(id);
    		return ResponseEntity.ok().body(MessageConstants.VENDOR_DELETED_SUCCESS);			
		} catch (Exception e) {
			logger.error("Error deleting vendor", e);
			return ResponseEntity.ok().body(MessageConstants.VENDOR_DELETED_FAILED);			
		}
    }
    
    @PostMapping("/login")
    public ResponseEntity<VendorDto> doVendorLogin(@RequestBody VendorDto vendorDto){
    	try {
            VendorDto vendor = vendorService.dologin(vendorDto);
            if (vendor == null) {
                return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(vendor, HttpStatus.OK);
        } catch (Exception e) {
            // Log the exception for debugging
            logger.error("Error logging in vendor", e);
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
   
}
