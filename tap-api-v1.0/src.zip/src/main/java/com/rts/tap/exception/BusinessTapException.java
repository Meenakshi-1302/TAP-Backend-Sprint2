package com.rts.tap.exception;

public class BusinessTapException extends Throwable {

	
	private static final long serialVersionUID = 1L;
	
	public BusinessTapException(String message) {
		super(message);
	}

}
