package com.rts.tap.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rts.tap.constants.APIConstants;
import com.rts.tap.model.Candidate;
import com.rts.tap.service.CandidateService;

@CrossOrigin(origins=APIConstants.FRONT_END_URL)
@RestController
@RequestMapping(path=APIConstants.BASE_CANDIDATE_URL)
public class CandidateController {

    private CandidateService candidateService;

    public CandidateController(CandidateService candidateService) {
		super();
		this.candidateService = candidateService;
	}

	@PostMapping(path=APIConstants.SAVE_CANDIDATE_URL)
    public void createCandidate(@RequestBody Candidate candidate) {
        candidateService.save(candidate);
    }

    @GetMapping(path=APIConstants.GET_ALL_CANDIDATE_URL)
    public List<Candidate> getAllCandidates() {
        return candidateService.findAll();
    }

    @GetMapping(path=APIConstants.GET_BY_ID_CANDIDATE_URL)
    public Candidate getCandidateById(@PathVariable Long id) {
        return candidateService.findById(id);
    }

    @PutMapping(path=APIConstants.UPDATE_CANDIDATE_URL)
    public void updateCandidate(@PathVariable Long id, @RequestBody Candidate candidate) {
        candidate.setCandidateId(id);
        candidateService.update(candidate);
    }

    @DeleteMapping(path=APIConstants.DELETE_CANDIDATE_URL)
    public void deleteCandidate(@PathVariable Long id) {
        candidateService.delete(id);
    }
}

