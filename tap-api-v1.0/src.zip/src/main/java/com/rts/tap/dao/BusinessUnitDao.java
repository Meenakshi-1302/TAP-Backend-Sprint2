package com.rts.tap.dao;


import com.rts.tap.model.BusinessUnit;

public interface BusinessUnitDao {

	void save(BusinessUnit businessUnit);
//	List<Organization> getAllOrganization();
	
}

