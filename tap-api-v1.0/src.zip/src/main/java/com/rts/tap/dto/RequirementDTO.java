//package com.rts.tap.dto;
//
//public class RequirementDTO {
//
//	private Long requirementId;
//
//	private int requiredResourceCount;
//
//	private String probableDesignation;
//
//	private String requiredSkills;
//
//	private String requiredExperience;
//
//	private String jobLocation;
//
//	private String timeline;
//
//	private double minimumBudget;
//
//	private double maximumBudget;
//
//	private Long clientId;
//
//	public RequirementDTO() {
//		super();
//	}
//
//	public Long getRequirementId() {
//		return requirementId;
//	}
//
//	public void setRequirementId(Long requirementId) {
//		this.requirementId = requirementId;
//	}
//
//	public int getRequiredResourceCount() {
//		return requiredResourceCount;
//	}
//
//	public void setRequiredResourceCount(int requiredResourceCount) {
//		this.requiredResourceCount = requiredResourceCount;
//	}
//
//	public String getProbableDesignation() {
//		return probableDesignation;
//	}
//
//	public void setProbableDesignation(String probableDesignation) {
//		this.probableDesignation = probableDesignation;
//	}
//
//	public String getRequiredSkills() {
//		return requiredSkills;
//	}
//
//	public void setRequiredSkills(String requiredSkills) {
//		this.requiredSkills = requiredSkills;
//	}
//
//	public String getRequiredExperience() {
//		return requiredExperience;
//	}
//
//	public void setRequiredExperience(String requiredExperience) {
//		this.requiredExperience = requiredExperience;
//	}
//
//	public String getJobLocation() {
//		return jobLocation;
//	}
//
//	public void setJobLocation(String jobLocation) {
//		this.jobLocation = jobLocation;
//	}
//
//	public String getTimeline() {
//		return timeline;
//	}
//
//	public void setTimeline(String timeline) {
//		this.timeline = timeline;
//	}
//
//	public double getMinimumBudget() {
//		return minimumBudget;
//	}
//
//	public void setMinimumBudget(double minimumBudget) {
//		this.minimumBudget = minimumBudget;
//	}
//
//	public double getMaximumBudget() {
//		return maximumBudget;
//	}
//
//	public void setMaximumBudget(double maximumBudget) {
//		this.maximumBudget = maximumBudget;
//	}
//
//	public Long getClientId() {
//		return clientId;
//	}
//
//	public void setClientId(Long clientId) {
//		this.clientId = clientId;
//	}
//
//}
