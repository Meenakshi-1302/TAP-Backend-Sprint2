package com.rts.tap.service;

import com.rts.tap.model.BusinessUnit;

public interface BusinessUnitService {
	
	void addBusinessUnit(BusinessUnit businessUnit);
     
}
