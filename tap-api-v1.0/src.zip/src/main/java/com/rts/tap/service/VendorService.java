package com.rts.tap.service;

import java.util.List;

import com.rts.tap.dto.VendorDto;
import com.rts.tap.model.Vendor;

import jakarta.mail.MessagingException;

public interface VendorService {
	public Vendor addNewVendor(VendorDto vendor) throws MessagingException;

	public VendorDto getVendorById(Long id);

	public List<VendorDto> getAllVendors();

	public Vendor updateVendor(Long id, VendorDto vendor);

	public String deleteVendor(Long id);

	public String generateVendorUsername(String name);

	public String generateStrongPassword();
	
	public VendorDto dologin(VendorDto vendorDto);
}
