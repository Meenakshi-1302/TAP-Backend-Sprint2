package com.rts.tap.dao;


import com.rts.tap.model.LoginCredentials;

public interface LoginCredentialsDao {
	LoginCredentials save(LoginCredentials loginCredentials);
   
}
