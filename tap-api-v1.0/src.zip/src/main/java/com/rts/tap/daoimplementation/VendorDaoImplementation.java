package com.rts.tap.daoimplementation;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.rts.tap.constants.MessageConstants;
import com.rts.tap.dao.VendorDao;
import com.rts.tap.dto.VendorDto;
import com.rts.tap.emailservice.VendorMailService;
import com.rts.tap.model.Vendor;

import jakarta.mail.MessagingException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import jakarta.transaction.Transactional;

/**
 * author: Jeevarajan Rajarajacholan 
 * version: v1.0 
 * updated at: 29-10-2024
 **/

@Repository
@Transactional
public class VendorDaoImplementation implements VendorDao {

	private EntityManager entityManager;
	private VendorMailService mailService;

	public VendorDaoImplementation(EntityManager entityManager, VendorMailService mailService) {
		super();
		this.entityManager = entityManager;
		this.mailService = mailService;
	}

	@Override
	public Vendor save(VendorDto vendor) throws MessagingException {		
		Vendor newVendor = new Vendor();
		newVendor.setOrganizationName(vendor.getOrganizationName());
		newVendor.setVendorUsername(vendor.getVendorUsername());
		newVendor.setEmail(vendor.getEmail());
		newVendor.setPassword(vendor.getPassword());
		entityManager.persist(newVendor);
		mailService.sendVendorCredentials(vendor);
		return newVendor;
	}

	@Override
	public Vendor findById(Long id) {
		return entityManager.find(Vendor.class, id);
	}

	@Override
	public List<Vendor> findAllVendor() {
		return entityManager.createQuery("SELECT v FROM Vendor v", Vendor.class).getResultList();
	}

	@Override
	public String deleteById(Long id) {
		Vendor vendor = findById(id);
		if (vendor != null) {
			entityManager.remove(vendor);
			return MessageConstants.VENDOR_DELETED_SUCCESS;
		} else {
			return MessageConstants.VENDOR_DELETED_FAILED;
		}
	}

	@Override
	public Vendor updateVendor(long id, VendorDto vendor) {
		Vendor existingVendor = findById(id);
		if (existingVendor != null) {
			existingVendor.setAddress(vendor.getAddress());
			existingVendor.setContactName(vendor.getContactName());
			existingVendor.setContactNumber(vendor.getContactNumber());
			existingVendor.setEmail(vendor.getEmail());
			existingVendor.setIsPasswordChanged(vendor.getIsPasswordChanged());
			existingVendor.setOrganizationName(vendor.getOrganizationName());
			existingVendor.setPassword(vendor.getPassword());
			existingVendor.setTaxIdentifyNumber(vendor.getTaxIdentifyNumber());
			existingVendor.setVendorOrganizationLogo(vendor.getVendorOrganizationLogo());
			return entityManager.merge(existingVendor);
		} else {
			return null;
		}
	}
	
	@Override
	public Vendor login(VendorDto vendorDto) {
		String username = vendorDto.getVendorUsername();
		String email = vendorDto.getEmail();
		String password = vendorDto.getPassword();
		if(email != null) {
			String emailLoginQuery= "SELECT v FROM Vendor v WHERE v.thirdPartyCredentitals.email=:email AND v.thirdPartyCredentitals.password = :password";
			Query query = entityManager.createQuery(emailLoginQuery).setParameter("email", email).setParameter("password", password);
			return (Vendor)query.getSingleResult(); 			
		} else {
			String usernameLoginQuery= "SELECT v FROM Vendor v WHERE v.thirdPartyCredentitals.username=:username AND v.thirdPartyCredentitals.password = :password";
			Query query = entityManager.createQuery(usernameLoginQuery).setParameter("username", username).setParameter("password", password);
			return (Vendor)query.getSingleResult(); 						
		}			
	}

}
