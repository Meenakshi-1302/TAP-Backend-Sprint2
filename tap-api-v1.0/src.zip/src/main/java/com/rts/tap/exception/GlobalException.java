package com.rts.tap.exception;

public class GlobalException extends Throwable {

	private static final long serialVersionUID = 1L;
	
	public GlobalException(String message) {
		super(message);
	}

}
