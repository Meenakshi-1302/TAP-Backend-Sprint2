package com.rts.tap.service;

import com.rts.tap.model.WorkFlow;

public interface WorkFlowService {

	WorkFlow getWorkflowByMrfIdForRecruitmentProcess(Long mrfId);

}
