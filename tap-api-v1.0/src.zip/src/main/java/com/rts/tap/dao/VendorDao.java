package com.rts.tap.dao;

import java.util.List;

import com.rts.tap.dto.VendorDto;
import com.rts.tap.model.Vendor;

import jakarta.mail.MessagingException;

/** 
 * author: Jeevarajan Rajarajacholan
 * version: v1.0
 * updated at: 04-11-2024
**/

public interface VendorDao {
	
	Vendor save(VendorDto vendor) throws MessagingException;

	Vendor updateVendor(long id, VendorDto existingVendor);

	String deleteById(Long id);

	Vendor findById(Long id);

	List<Vendor> findAllVendor();
	
	Vendor login(VendorDto vendorDto);
	
	
}
