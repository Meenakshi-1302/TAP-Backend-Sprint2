package com.rts.tap.service;

import com.rts.tap.model.Candidate;

import java.util.List;

public interface CandidateService {
    void save(Candidate candidate);
    List<Candidate> findAll();
    Candidate findById(Long id);
    void update(Candidate candidate);
    void delete(Long id);
}

