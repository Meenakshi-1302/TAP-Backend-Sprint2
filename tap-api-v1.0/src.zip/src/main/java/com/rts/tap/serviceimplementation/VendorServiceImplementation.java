package com.rts.tap.serviceimplementation;

import java.security.SecureRandom;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.rts.tap.constants.MessageConstants;
import com.rts.tap.dao.VendorDao;
import com.rts.tap.dto.VendorDto;
import com.rts.tap.exception.VendorNotFoundException;
import com.rts.tap.model.Vendor;
import com.rts.tap.service.VendorService;

import jakarta.mail.MessagingException;
import jakarta.transaction.Transactional;

/** 
 * author: Jeevarajan, Vashanth 
 * version: v1.0
 * updated at: 04-11-2024
**/

@Service
@Transactional
public class VendorServiceImplementation implements VendorService {

	private final VendorDao vendorDao;

	public VendorServiceImplementation(VendorDao vendorDao) {
		this.vendorDao = vendorDao;
	}

	@Override
	public Vendor addNewVendor(VendorDto vendor) throws MessagingException {
		vendor.setVendorUsername(generateVendorUsername(vendor.getOrganizationName()));
		vendor.setPassword(generateStrongPassword());
		return vendorDao.save(vendor);
	}

	@Override
	public VendorDto getVendorById(Long id) {
		Vendor vendor = vendorDao.findById(id);
		if (vendor == null) {
			throw new VendorNotFoundException(MessageConstants.VENDOR_NOT_FOUND);
		}
		VendorDto vendorDto = new VendorDto();
		BeanUtils.copyProperties(vendor, vendorDto);
		return vendorDto;
	}

	@Override
	public List<VendorDto> getAllVendors() {
		return vendorDao.findAllVendor().stream().map(vendor -> {
			VendorDto vendorDto = new VendorDto();
			BeanUtils.copyProperties(vendor, vendorDto);
			return vendorDto;
		}).collect(Collectors.toList());
	}

	@Override
	public Vendor updateVendor(Long id, VendorDto vendor) {
		Vendor existingVendor = vendorDao.findById(id);
		if (existingVendor == null) {
			throw new VendorNotFoundException(MessageConstants.VENDOR_NOT_FOUND);
		}
//	        BeanUtils.copyProperties(vendorDto, existingVendor, "vendorid");
		return vendorDao.updateVendor(id, vendor);
	}

	@Override
	public String deleteVendor(Long id) {
		try {
			vendorDao.deleteById(id);
			return MessageConstants.VENDOR_DELETED_SUCCESS;
		} catch (Exception e) {
			return MessageConstants.VENDOR_DELETED_FAILED;
		}
	}

	@Override
	public String generateVendorUsername(String name) {
		String prefix = name.length() >= 3 ? name.substring(0, 3).toLowerCase() : name.toLowerCase();
		Random random = new Random();
		StringBuilder digits = new StringBuilder();
		for (int i = 0; i < 5; i++) {
			digits.append(random.nextInt(10)); // Generates a digit between 0 and 9
		}
		String username = prefix + digits.toString();
		return username;
	}

	@Override
	public String generateStrongPassword() {
		SecureRandom random = new SecureRandom();
		StringBuilder password = new StringBuilder(12);
		for (int i = 0; i < 12; i++) {
			int index = random.nextInt(MessageConstants.CHARACTERS.length());
			password.append(MessageConstants.CHARACTERS.charAt(index));
		}
		return password.toString();
	}
	public VendorDto dologin(VendorDto vendorDto) {
		Vendor vendor = vendorDao.login(vendorDto);		
		VendorDto vendorObject = new VendorDto();
		vendorObject.setVendorId(vendor.getVendorId());
		vendorObject.setOrganizationName(vendor.getOrganizationName());
		vendorObject.setVendorUsername(vendor.getThirdPartyCredentitals().getUsername());
		vendorObject.setContactName(vendor.getContactName());
		vendorObject.setContactNumber(vendor.getContactNumber());
		vendorObject.setAddress(vendor.getAddress());
		vendorObject.setEmail(vendor.getThirdPartyCredentitals().getEmail());
		vendorObject.setPassword(vendor.getThirdPartyCredentitals().getPassword());
		vendorObject.setWebsiteUrl(vendor.getWebsiteUrl());
		vendorObject.setTaxIdentifyNumber(vendor.getTaxIdentifyNumber());
		vendorObject.setIsPasswordChanged(vendor.getIsPasswordChanged());
		vendorObject.setRole(vendor.getThirdPartyCredentitals().getRole().getRole());		
		return vendorObject;
	}
}
