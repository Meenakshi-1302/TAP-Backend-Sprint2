package com.rts.tap.dao;

import com.rts.tap.model.Admin;

public interface AdminDao {

	void save(Admin admin);
	
}

