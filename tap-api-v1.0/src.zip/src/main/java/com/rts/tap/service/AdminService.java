package com.rts.tap.service;

import com.rts.tap.model.Admin;

public interface AdminService {
	
    void addAdmin(Admin admin);
     
}
