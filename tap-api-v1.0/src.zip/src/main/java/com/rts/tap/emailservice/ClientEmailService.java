package com.rts.tap.emailservice;

public interface ClientEmailService {

	public String sendOtp(String clientEmail);
}
